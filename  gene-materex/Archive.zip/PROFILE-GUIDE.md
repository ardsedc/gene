# دليل رفع واستخدام البروفايل

## 📋 كيفية رفع البروفايل على الموقع

هذا الملف يحتوي على دليل شامل لكيفية إضافة البروفايل (Profile) إلى موقع Gene Matrix.

---

## 🎯 الخيارات المتاحة

### الخيار 1: استخدام قسم "من نحن" الموجود

الموقع يحتوي بالفعل على قسم "من نحن" (About Us) الذي يتضمن:
- ✅ الرؤية والرسالة
- ✅ القيم الجوهرية
- ✅ التزامنا برؤية 2030

يمكنك تحديث محتوى هذا القسم بالمعلومات من ملف البروفايل الخاص بك.

**الموقع في الكود:**
```html
<!-- في ملف index.html -->
<section id="about" class="about">
    <!-- محتوى البروفايل هنا -->
</section>
```

---

### الخيار 2: إنشاء صفحة بروفايل منفصلة

إذا كنت تريد صفحة بروفايل منفصلة، يمكنك:

#### أ. إنشاء ملف جديد: `profile.html`

1. انسخ محتوى `index.html`
2. احذف الأقسام غير المرغوبة
3. أضف محتوى البروفايل

#### ب. إضافة رابط في القائمة

في ملف `index.html`، أضف رابط البروفايل:

```html
<ul class="nav-menu" id="navMenu">
    <li><a href="profile.html">البروفايل</a></li>
    <!-- باقي الروابط -->
</ul>
```

---

### الخيار 3: إضافة قسم بروفايل في الصفحة الرئيسية

يمكنك إضافة قسم جديد بعد قسم "من نحن":

```html
<!-- بعد قسم About -->
<section id="profile" class="profile">
    <div class="container">
        <div class="section-header">
            <h2 class="section-title">البروفايل</h2>
            <p class="section-subtitle">تعرف على فريقنا وخبراتنا</p>
        </div>
        
        <!-- محتوى البروفايل هنا -->
        <div class="profile-content">
            <div class="profile-card">
                <div class="profile-image">
                    <!-- صورة البروفايل -->
                </div>
                <div class="profile-info">
                    <h3>الاسم</h3>
                    <p>المنصب</p>
                    <p>الوصف</p>
                </div>
            </div>
        </div>
    </div>
</section>
```

---

## 📝 خطوات إضافة محتوى البروفايل

### 1. إذا كان لديك ملف PDF أو PowerPoint

#### أ. استخراج النصوص:
- افتح الملف (`Gene-Matrix.pptx.pdf`)
- انسخ النصوص التي تريدها
- الصقها في الأقسام المناسبة

#### ب. استخراج الصور:
- احفظ الصور من الملف
- ضعها في مجلد `images/`
- استبدل `image-placeholder` بالصور الفعلية

### 2. إذا كان لديك ملف نصي

انسخ المحتوى والصقه مباشرة في الأقسام المناسبة.

---

## 🎨 تصميم البروفايل (مقترح)

### على الموبايل:
```
┌─────────────────────┐
│  صورة البروفايل    │
│     (دائري)         │
├─────────────────────┤
│  الاسم              │
│  المنصب             │
│  الوصف              │
├─────────────────────┤
│  الخبرات            │
│  [بطاقات]           │
├─────────────────────┤
│  الإنجازات          │
│  [بطاقات]           │
└─────────────────────┘
```

### على الديسكتوب:
```
┌──────────────────┬──────────────────┐
│  صورة البروفايل  │  الاسم           │
│                  │  المنصب          │
│                  │  الوصف           │
│                  │                  │
│                  │  الخبرات         │
│                  │  الإنجازات       │
└──────────────────┴──────────────────┘
```

---

## 💻 أمثلة على كود البروفايل

### مثال 1: بروفايل بسيط

```html
<section id="profile" class="profile">
    <div class="container">
        <div class="profile-card">
            <div class="profile-image">
                <img src="images/profile.jpg" alt="Profile Picture">
            </div>
            <div class="profile-info">
                <h2>الاسم الكامل</h2>
                <p class="profile-title">المنصب</p>
                <p class="profile-description">
                    الوصف أو السيرة الذاتية هنا
                </p>
            </div>
        </div>
    </div>
</section>
```

### مثال 2: بروفايل مع بطاقات

```html
<section id="profile" class="profile">
    <div class="container">
        <div class="profile-header">
            <div class="profile-image">
                <img src="images/profile.jpg" alt="Profile">
            </div>
            <div class="profile-basic-info">
                <h2>الاسم</h2>
                <p>المنصب</p>
            </div>
        </div>
        
        <div class="profile-sections">
            <div class="profile-section">
                <h3>الخبرات</h3>
                <div class="experience-cards">
                    <!-- بطاقات الخبرات -->
                </div>
            </div>
            
            <div class="profile-section">
                <h3>الإنجازات</h3>
                <div class="achievement-cards">
                    <!-- بطاقات الإنجازات -->
                </div>
            </div>
        </div>
    </div>
</section>
```

---

## 🎨 إضافة CSS للبروفايل

أضف هذه الأنماط في ملف `styles.css`:

```css
/* Profile Section */
.profile {
    background: var(--bg-light);
    padding: var(--spacing-3xl) var(--spacing-sm);
}

.profile-card {
    background: var(--bg-white);
    border-radius: var(--radius-lg);
    padding: var(--spacing-xl);
    box-shadow: var(--shadow-lg);
    text-align: center;
}

.profile-image {
    width: 150px;
    height: 150px;
    margin: 0 auto var(--spacing-lg);
    border-radius: var(--radius-full);
    overflow: hidden;
    border: 4px solid var(--primary-color);
}

.profile-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.profile-info h2 {
    font-size: 2rem;
    font-weight: 700;
    margin-bottom: var(--spacing-xs);
    color: var(--text-dark);
}

.profile-title {
    font-size: 1.25rem;
    color: var(--primary-color);
    font-weight: 600;
    margin-bottom: var(--spacing-md);
}

.profile-description {
    color: var(--text-medium);
    line-height: 1.8;
    max-width: 600px;
    margin: 0 auto;
}

@media (min-width: 768px) {
    .profile-card {
        display: grid;
        grid-template-columns: 200px 1fr;
        gap: var(--spacing-xl);
        text-align: right;
        align-items: center;
    }
    
    .profile-image {
        margin: 0;
    }
}
```

---

## 📱 التأكد من التجاوب على الموبايل

1. **صورة البروفايل**: يجب أن تكون دائرية أو مربعة
2. **حجم الصورة**: لا تقل عن 150x150px على الموبايل
3. **النص**: حجم خط لا يقل عن 16px
4. **المسافات**: مسافات مناسبة بين العناصر

---

## ✅ قائمة التحقق

قبل إضافة البروفايل، تأكد من:

- [ ] لديك محتوى البروفايل جاهز
- [ ] لديك صورة البروفايل (إن وجدت)
- [ ] اخترت المكان المناسب (قسم منفصل أو ضمن "من نحن")
- [ ] أضفت CSS المناسب
- [ ] اختبرت على الموبايل
- [ ] اختبرت على الديسكتوب
- [ ] تأكدت من التجاوب

---

## 🚀 الخطوات التالية

بعد إضافة البروفايل:

1. ✅ اختبر الموقع على أجهزة مختلفة
2. ✅ تأكد من تحميل الصور بشكل صحيح
3. ✅ تحقق من التجاوب على جميع الأجهزة
4. ✅ اختبر الروابط والتنقل
5. ✅ اختبر السرعة والأداء

---

## 📞 المساعدة

إذا واجهت أي مشاكل:

1. راجع ملف `index.html` للمثال
2. راجع ملف `styles.css` للتصميم
3. تحقق من تعليقات الكود
4. اختبر في المتصفح (F12 للـ DevTools)

---

**بالتوفيق! 🚀**

